#Sys.setenv(JAVA_HOME='C:\\Program Files\\Java\\jre7')
#library(rJava)

install.packages("shiny")
library(shiny)

runApp("iris_shiny")
